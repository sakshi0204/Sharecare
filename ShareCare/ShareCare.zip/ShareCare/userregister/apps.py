from django.apps import AppConfig


class UserregisterConfig(AppConfig):
    name = 'userregister'
